from classes_modules import Undergrad, Grad_Student
from Function_modules import create_student

def main():
    student_info = create_student()
    if student_info:
        if student_info['level'] == 'undergrad':
            undergrad_student = Undergrad(student_info['first_name'], student_info['last_name'], student_info['level'], student_info['major'], student_info['concentration'], student_info['middle_name'])
            print("New undergraduate student created:")
            print(undergrad_student.create_undergrad_student())
        elif student_info['level'] == 'grad_student':
            grad_student = Grad_Student(student_info['first_name'], student_info['last_name'], student_info['level'], student_info['major'], student_info['concentration'], student_info['thesis_topic'], student_info['middle_name'])
            print("New graduate student created:")
            print(grad_student.create_grad_student())
    else:
        print("Error: Invalid student information.")

if __name__ == "__main__":
    main() 