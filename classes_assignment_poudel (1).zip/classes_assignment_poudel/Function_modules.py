def create_student():
    level = input("Enter student's level as either undergrad or grad_student: ").lower()
    if level == 'undergrad':
        first_name = input("Enter first name: ").lower()
        last_name = input("Enter last name: ").lower()
        middle_name = input("Enter middle name (if any): ").lower()
        major = input("Enter major: ").lower()
        concentration = input("Enter concentration: ").lower()
        return {'level': level, 'first_name': first_name, 'last_name': last_name, 'middle_name': middle_name, 'major': major, 'concentration': concentration}
    elif level == 'grad_student':
        first_name = input("Enter first name: ").lower()
        last_name = input("Enter last name: ").lower()
        middle_name = input("Enter middle name (if any): ").lower()
        major = input("Enter major: ").lower()
        concentration = input("Enter concentration: ").lower()
        thesis_topic = input("Enter thesis topic: ").lower()
        return {'level': level, 'first_name': first_name, 'last_name': last_name, 'middle_name': middle_name, 'major': major, 'concentration': concentration, 'thesis_topic': thesis_topic}
    else:
        return None
